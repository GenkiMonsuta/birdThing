
var birdList = [
    {'dutch' : 'houtduif',
        'picture' : 'columbapalumbus.jpg'
    },
    {'dutch' : 'groene specht',
        'picture' : 'picusviridus.jpg'
    },
    {'dutch' : 'grote bonte specht',
        'picture' : 'dendrocoposmajor.jpg'
    },
    {'dutch' : 'gaai',
        'picture' : 'garrulusglandarius.jpg'
    },
    {'dutch' : 'raaf',
        'picture' : 'corvuscorax.jpg'
    }
];
