/**
 * Created by Kirste on 27/11/14.
 */
var birdList = [
    {'latin' : 'Columba Palumbus',
        'dutch' : 'houtduif'
    },
    {'latin' : 'Picus Viridus',
        'dutch' : 'groene specht'
    },
    {'latin' : 'Dendrocopos Major',
        'dutch' : 'grote bonte specht'
    },
    {'latin' : 'Garrulus Glandarius',
        'dutch' : 'gaai'
    },
    {'latin' : 'Corvus Corax',
        'dutch' : 'raaf'
    },
    {'latin' : 'Parus Caeruleus',
        'dutch' : 'pimpelmees'
    },
    {'latin' : 'Parus Major',
        'dutch' : 'koolmees'
    },
    {'latin' : 'Turdus Merula',
        'dutch' : 'merel'
    },
    {'latin' : 'Erithacus Rubecula',
        'dutch' : 'roodborst'
    },
    {'latin' : 'Fringilla Coelebs',
        'dutch' : 'vink'
    },
    {'latin' : 'Phasanius Colchicus',
        'dutch' : 'fazant'
    },
    {'latin' : 'Buteo Buteo',
        'dutch' : 'Buizerd'
    },
    {'latin' : 'Falco Tinnunculus',
        'dutch' : 'torenvalk'
    },
    {'latin' : 'Vanellus Vannellus',
        'dutch' : 'kievit'
    },
    {'latin' : 'Streptopelia Decaocto',
        'dutch' : 'turkse tortelduif'
    },
    {'latin' : 'Streptopelia Turtur',
        'dutch' : 'tortelduif'
    },
    {'latin' : 'Pica Pica',
        'dutch' : 'ekster'
    },
    {'latin' : 'Coloeus Monedula',
        'dutch' : 'kauw'
    },
    {'latin' : 'Passer Domesticus',
        'dutch' : 'huismus'
    },
    {'latin' : 'Branta Canadesis',
        'dutch' : 'grote canadese gans'
    },
    {'latin' : 'Anas Platyrhynchos',
        'dutch' : 'wilde eend'
    },
    {'latin' : 'Ardea Cinerea',
        'dutch' : 'blauwe reiger'
    },
    {'latin' : 'Gallinula Chloropus',
        'dutch' : 'waterhoen'
    },
    {'latin' : 'Fulica Atra',
        'dutch' : 'meerkoet'
    },
    {'latin' : 'Larus Canus',
        'dutch' : 'stormmeeuw'
    },
    {'latin' : 'Larus Ribibundus',
        'dutch' : 'kokmeeuw'
    }
];