
var birdList = [
    {'latin' : 'Columba Palumbus',
        'picture' : 'columbapalumbus.jpg'
    },
    {'latin' : 'Picus Viridus',
        'picture' : 'picusviridus.jpg'
    },
    {'latin' : 'Dendrocopos Major',
        'picture' : 'dendrocoposmajor.jpg'
    },
    {'latin' : 'Garrulus Glandarius',
        'picture' : 'garrulusglandarius.jpg'
    },
    {'latin' : 'Corvus Corax',
        'picture' : 'corvuscorax.jpg'
    }
];